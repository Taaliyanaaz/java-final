package team1;


import java.util.List;
import java.util.Scanner;
import CustomException.IdNotFound;
import team2.EmployeeManagementTeam2; // Import team2
import team3.EmployeeManagementTeam3; // Import team3
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Menu {
    private static final int NULL = 0;

	public static void main(String[] args) {
		final Logger logger = LogManager.getLogger(Menu.class);
        Scanner scanner = new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("\nChoose the Implementation:");
            System.out.println("1. Employee Management with Normal File Operation (Team 3)");
            System.out.println("2. Employee Management with Serialization (Team 2)");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine(); 

            if (choice == 1) {
                EmployeeManagementTeam3 employeeManager = new EmployeeManagementTeam3("employee_data.txt");

                while (true) {
                    System.out.println("Menu:");
                    System.out.println("1. Add Employee");
                    System.out.println("2. Delete Employee");
                    System.out.println("3. Update Employee");
                    System.out.println("4. List Employees");
                    System.out.println("5. Exit");
                    System.out.print("Enter your choice: ");

                    int subChoice = scanner.nextInt();
                    scanner.nextLine(); 

                    switch (subChoice) {
                        case 1:
                            System.out.print("Enter Employee ID: ");
                            int employeeId = scanner.nextInt();
                            if(employeeManager.isExists(employeeId)) {
                            	System.out.println("Employee Id already exists");
                            }
                            else {
                            scanner.nextLine();
                            System.out.print("Enter Employee Name: ");
                            String employeeName = scanner.nextLine();
                            System.out.print("Enter Employee Salary: ");
                            double employeeSalary = scanner.nextDouble();
                            scanner.nextLine();
                            Employee employee = new Employee(employeeId, employeeName, employeeSalary);
                            employeeManager.addEmployee(employee);
                            String designation = CalculateDesignation.calculateDesignation(employee);
        	                System.out.println("Designation: " + designation);
        	                logger.info("Added successfully");
        	                System.out.println("Employee added successfully.");
                       
                            }
                            break;
                        case 2:
                            System.out.print("Enter Employee ID to delete: ");
                            int idToDelete = scanner.nextInt();
                            employeeManager.deleteEmployee(idToDelete);
                            break;
                        case 3:                        	
                        
                            System.out.print("Enter Employee ID to update: ");                            
                            int idToUpdate = scanner.nextInt();   
                           
                            scanner.nextLine(); // Consume the newline character
                            System.out.print("Enter new Name: ");
                            String newName = scanner.nextLine();
                            System.out.print("Enter new Salary: ");
                            double newSalary = scanner.nextDouble();
                            scanner.nextLine();
                            Employee newEmployee = new Employee(idToUpdate, newName, newSalary);
                            try {
                            employeeManager.updateEmployee(idToUpdate, newEmployee);   
                            //employeeManager.updateEmployee(employeeId, newEmployee);
                           }
                           catch(IdNotFound e){
                        	   System.out.println("Error: "+e.getMessage());
                        	   logger.error("this is error");
                        	   
                           }
                            break;
                            
                        case 4:
                            employeeManager.listEmployees();
                            break;
                        case 5:
                        	System.out.println("Terminated");
                            System.exit(0);
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                }
            } 
            else if (choice == 2) {
                EmployeeManagementTeam2 employeeManager = new EmployeeManagementTeam2("C:/Users/Taaliyanaaz/Downloads/GroupWork/GroupWork/employee_data.ser");

                while (true) {
                    System.out.println("Menu:");
                    System.out.println("1. Add Employee");
                    System.out.println("2. List Employees");
    	            System.out.println("3. update Employees");
    	            System.out.println("4. delete Employees");
    	            System.out.println("5. Exit");
                    System.out.print("Enter your choice: ");

                    int subChoice = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character

                    switch (subChoice) {
                        case 1:
                        	System.out.println("Enter Employee ID:");
        	                int id = scanner.nextInt();  
        	                if(employeeManager.isExists(id)) {
                            	System.out.println("Employee Id already exists");
                            }
        	                else {
        	                scanner.nextLine();
        	                System.out.println("Enter Employee Name:");        
        	                String name = scanner.nextLine();
        	                System.out.println("Enter Employee Salary:");
        	                double salary = scanner.nextDouble();
        	                scanner.nextLine(); 
        	                Employee employee = new Employee(id, name, salary);       
        	                employeeManager.addEmployee(employee);
        	                String designation = CalculateDesignation.calculateDesignation(employee);
        	                System.out.println("Designation: " + designation);
        	                System.out.println("Employee added successfully.");
        	                }
        	                break;
                        case 2:
                        	System.out.println("Employees List:");                       	 
        	                List<Employee> employees = employeeManager.listEmployees(); // Get the list of employees         
        	                if (employees.isEmpty()) {
        	                    System.out.println("No employees to display.");
        	                } else {
        	                  //  System.out.println("List of Employees:");
        	                    for (Employee employee1 : employees) {
        	                        System.out.println(employee1);
        	                    }
        	                }
        	                break;
                        
                   
                        case 3:
                            System.out.print("Enter the ID to update:");
                            int idToUpdate = scanner.nextInt();
                            scanner.nextLine(); // Consume the newline character

                            System.out.print("Enter new Name: ");
                            String newName = scanner.nextLine();

                            System.out.print("Enter new Salary: ");
                            double newSalary = scanner.nextDouble();
                            scanner.nextLine();

                            Employee newEmployee = new Employee(idToUpdate, newName, newSalary);

                            try {
                                employeeManager.updateEmployee(idToUpdate, newEmployee);
                                System.out.println("Employee updated successfully.");
                            } catch (IdNotFound e) {
                                System.out.println("Error: " + e.getMessage());
                            }
                            break;


                        case 4:
                        	  System.out.print("Please enter the employee ID: ");
                              int idToDelete = scanner.nextInt();
                              employeeManager.deleteEmployee(idToDelete);
                              System.out.print("Deleted id:" +idToDelete);
                              break;
                        case 5:
                        	System.out.println("Exiting the program.");
        	                break;
        	           
        	            default: System.out.println("Please Enter valid choice");
        	            }               	            
                
            }
            } 
            }
                    
        }    
    }
    
       
        
    